package mypac;

public class Utils {
    final static String BASE_URL = "https://formy-project.herokuapp.com/form";
    final static String BASE_URL_FORM = "http://the-internet.herokuapp.com/login";
    final static String BASE_URL_FILEUPLOAD = "http://the-internet.herokuapp.com/upload";
    final static String BASE_URL_IMGSHIFT = "http://the-internet.herokuapp.com/shifting_content/image";
    final static String BASE_URL_MENU = "http://the-internet.herokuapp.com/shifting_content/menu";
    final static String BASE_URL_TABLEDOM = "http://the-internet.herokuapp.com/challenging_dom";   
    final static String CHROME_DRIVER_LOCATION = "chromedriver";
}
